<?php
session_start();
include_once("conexao.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Cadastrar Produto</title>		
	</head>
	<body>
	
		<a href="cadastroproduto.php">Cadastrar Produto</a><br>
		<a href="listar.php">Listar Produto</a><br>
		<a href="listardescricao.php">Listar Descricao Produto</a><br>
		
		<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		?>
		
		<h1>Comente sobre os produtos</h1>

		<form name="descricao" method="POST" action="inseredescricao.php">
			
			<label>Selecione Produto:</label><br/><br/>
			
			<select name="codprod">
				<?php
					$sql="SELECT CODIGO, ' ' , NOME FROM PRODUTOS ORDER BY CODIGO";
					$res=mysqli_query($conn, $sql);
					while($vreg=mysqli_fetch_row($res)){
					$vcod=$vreg['0'];
					$vnome=$vreg['1'];
				echo "<option value='$vnome'>$vcod</option>";
				}
				?>
				
			</select>
			<br/><br/>
			
			<input type="text" name="codigo"  width="50" placeholder="Insira o código do produto"><br><br>
	
			<input type="text" name="descricao" size ="255" maxlength="255" width="50" placeholder="Insira o seu comentário sobre o produto"><br><br>
			
			<input type="submit" value="Cadastrar Comentário"></br></br>
		</form>
	</body>
</html>