<?php
session_start();
include_once("conexao.php");

$codigo = filter_input(INPUT_POST, 'codigo', FILTER_SANITIZE_STRING);
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$altura = filter_input(INPUT_POST, 'altura', FILTER_SANITIZE_NUMBER_FLOAT);
$largura = filter_input(INPUT_POST, 'largura', FILTER_SANITIZE_NUMBER_FLOAT);
$profundidade = filter_input(INPUT_POST, 'profundidade', FILTER_SANITIZE_NUMBER_FLOAT);


$result_produto = "INSERT INTO produtos (codigo, nome, altura, largura, profundidade, ultimaalteracao) 
VALUES ('$codigo', '$nome', '$altura','$largura','$profundidade', NOW())";
$resultado_produto = mysqli_query($conn, $result_produto);

if(mysqli_insert_id($conn)){
	$_SESSION['msg'] = "<p style='color:green;'>Produto cadastrado com sucesso</p>";
	header("Location: index.php");
}else{
	$_SESSION['msg'] = "<p style='color:red;'>Produto não foi cadastrado com sucesso</p>";	
	header("Location: index.php");
}

?>