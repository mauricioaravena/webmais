<?php
session_start();
include_once("conexao.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>Listar Produtos</title>		
	</head>
	<body>
		<a href="index.php">Início</a><br>
		<a href="listar.php">Listar</a><br>
		<h1>Listar Usuário</h1>
		<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		
		//Receber o número da página
		$pagina_atual = filter_input(INPUT_GET,'pagina', FILTER_SANITIZE_NUMBER_INT);		
		$pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
		
		//Setar a quantidade de itens por pagina
		$qnt_result_pg = 5;
		
		//calcular o inicio visualização
		$inicio = ($qnt_result_pg * $pagina) - $qnt_result_pg;
		
		$result_descricoes = "SELECT D.codigoproduto codigo,(SELECT P.NOME FROM PRODUTOS P WHERE P.CODIGO = D.CODIGOPRODUTO) nome, D.Descricao descricao FROM descricoesProduto D LIMIT $inicio, $qnt_result_pg";
		$resultado_descricoes = mysqli_query($conn, $result_descricoes);
		while($row_descricao = mysqli_fetch_assoc($resultado_descricoes)){
			if($row_descricao['codigo']){
			echo "Codigo: " . $row_descricao['codigo'] . "<br>";
			echo "Nome: " . $row_descricao['nome'] . "<br><hr>";
		}
			echo "Descricao: " . $row_descricao['descricao'] . "<br><hr>";
		}
		
		//Pagina - Somar a quantidade de produtos
		$result_pg = "SELECT COUNT(codigoproduto) AS num_result FROM descricoesproduto";
		$resultado_pg = mysqli_query($conn, $result_pg);
		$row_pg = mysqli_fetch_assoc($resultado_pg);
		//echo $row_pg['num_result'];
		//Quantidade de pagina 
		$quantidade_pg = ceil($row_pg['num_result'] / $qnt_result_pg);
		
		//Limitar os link antes depois
		$max_links = 2;
		echo "<a href='listardescricao.php?pagina=1'>Primeira</a> ";
		
		for($pag_ant = $pagina - $max_links; $pag_ant <= $pagina - 1; $pag_ant++){
			if($pag_ant >= 1){
				echo "<a href='listardescricao.php?pagina=$pag_ant'>$pag_ant</a> ";
			}
		}
			
		echo "$pagina ";
		
		for($pag_dep = $pagina + 1; $pag_dep <= $pagina + $max_links; $pag_dep++){
			if($pag_dep <= $quantidade_pg){
				echo "<a href='listardescricao.php?pagina=$pag_dep'>$pag_dep</a> ";
			}
		}
		
		echo "<a href='listardescricao.php?pagina=$quantidade_pg'>Ultima</a>";
		
		?>		
	</body>
</html>