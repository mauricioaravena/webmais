-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 23-Dez-2018 às 11:37
-- Versão do servidor: 5.7.23
-- versão do PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `produtos`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `descricoesproduto`
--

DROP TABLE IF EXISTS `descricoesproduto`;
CREATE TABLE IF NOT EXISTS `descricoesproduto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigoproduto` varchar(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `datainsercao` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codigoproduto` (`codigoproduto`),
  KEY `codigoproduto_2` (`codigoproduto`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `descricoesproduto`
--

INSERT INTO `descricoesproduto` (`id`, `codigoproduto`, `descricao`, `datainsercao`) VALUES
(1, 'PD0001', 'Descricao produto PD0001', '2018-12-23 02:11:51'),
(2, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 02:13:51'),
(3, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 02:29:45'),
(4, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 02:44:16'),
(5, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 10:34:50'),
(6, '', 'usbflaiuhghiaurdh', '2018-12-23 10:58:28'),
(7, '', 'ComentÃ¡rio Sobre o produto 2', '2018-12-23 11:05:53'),
(8, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 11:12:13'),
(9, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 11:13:28'),
(10, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 11:16:07'),
(11, '', 'ComentÃ¡rio Sobre o produto 2', '2018-12-23 11:23:41'),
(12, '', 'ComentÃ¡rio sobre o produto PD0001', '2018-12-23 11:32:11'),
(13, 'PD0006', 'ComentÃ¡rio sobre o produto PD0006', '2018-12-23 12:08:50'),
(14, '', 'ComentÃ¡rio sobre o produto PD004', '2018-12-23 12:40:03'),
(15, 'PD0006', 'ComentÃ¡rio sobre o produto PD0006', '2018-12-23 12:55:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `altura` double NOT NULL,
  `largura` double NOT NULL,
  `profundidade` double NOT NULL,
  `ultimaalteracao` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigoproduto` (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `codigo`, `nome`, `altura`, `largura`, `profundidade`, `ultimaalteracao`) VALUES
(1, 'PD0001', 'Bola Oficial', 1.1, 1.1, 1.1, '2018-12-22 20:42:14'),
(3, 'PD0002', 'Bola Oficial', 11, 110, 11, '2018-12-22 21:33:35'),
(4, 'PD0003', 'Garrafa', 4, 2, 5, '2018-12-23 02:03:17'),
(5, 'PD0004', 'Carteira', 1, 105, 155, '2018-12-23 02:06:18'),
(6, 'PD0005', 'Mouse', 3, 9, 115, '2018-12-23 02:07:30'),
(7, 'PD0006', 'Mesa', 15, 11, 12, '2018-12-23 12:07:41');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
