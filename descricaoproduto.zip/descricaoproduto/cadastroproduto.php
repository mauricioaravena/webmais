<?php
	session_start();
	include_once("conexao.php");
?>

<html lang="pt-br">
	<head>
		<meta charset="utf-8"/>
		<title>Descricao Produtos</title>		
	</head>
	<body>
	
		<h1>Cadastrar Produto</h1>
		<?php
		if(isset($_SESSION['msg'])){
			echo $_SESSION['msg'];
			unset($_SESSION['msg']);
		}
		?>
		<form method="POST" action="insere.php">
			<label>Codigo Produto: </label>
			<input type="text" name="codigo" placeholder="Digite o codigo do produto"><br><br>
			
			<label>Nome Produto: </label>
			<input type="text" name="nome" placeholder="Digite o nome do produto"><br><br>

			<label>Altura Produto: </label>
			<input type="float" name="altura" placeholder="Digite a altura do produto"><br><br>

			<label>Largura Produto: </label>
			<input type="float" name="largura" placeholder="Digite a largura do produto"><br><br>

			<label>Profundidade Produto: </label>
			<input type="float" name="profundidade" placeholder="Digite a profundidade do produto"><br><br>

			<input type="submit" value="Cadastrar"></br></br>
			<?php
			if(isset($_SESSION['msg'])){
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			?>
			<a href="index.php">Retornar ao menu</a><br>
		</form>
	</Body>
</html>	