<?php
session_start();
include_once("conexao.php");

	$codigo=filter_input(INPUT_POST, 'codigo', FILTER_SANITIZE_STRING);
	$descricao=filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
	
	
	$sql= "INSERT INTO descricoesproduto (codigoproduto, descricao, datainsercao) 
VALUES ('$codigo', '$descricao', NOW())";
$descricao_produto = mysqli_query($conn, $sql);

if(mysqli_insert_id($conn)){
	$_SESSION['msg'] = "<p style='color:green;'>Comentário cadastrado com sucesso</p>";
	header("Location: index.php");
}else{
	$_SESSION['msg'] = "<p style='color:red;'>Comentário não foi cadastrado com sucesso</p>";
	header("Location: index.php");
}

?>

