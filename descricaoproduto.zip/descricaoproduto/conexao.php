<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$dbname = "produtos";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);