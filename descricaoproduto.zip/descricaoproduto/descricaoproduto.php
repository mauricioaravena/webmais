<?php
	session_start();
	include_once("conexao.php");
?>

<html lang="pt-br">
	<head>
		<meta charset="utf-8"/>
		<title>Descricao Produtos</title>		
	</head>
	<body>
	
		<h1>Comente sobre os produtos</h1>

		<form name="descricao" method="POST" action="inseredescricao.php">
			
			<label>Selecione Produto:</label><br/><br/>
			
			<select name="nome">
				<?php
					$sql="SELECT * FROM PRODUTOS ORDER BY CODIGO";
					$res=mysqli_query($conn, $sql);
					while($vreg=mysqli_fetch_row($res)){
					$codigo=$vreg[0];
					$vnome=$vreg[1];
				echo "<option value=$vnome>$vcod</option>";
				}
				?>
			</select>
			<br/><br/>
			
			<input type="hidden" name="codigo" value="<?php echo $vreg['codigo']; ?>"><br><br>
	
			<input type="text" name="descricao" size ="255" maxlength="255" width="50" placeholder="Insira o seu comentário sobre o produto"><br><br>
			
			<input type="submit" value="Cadastrar Comentário"></br></br>
			
			<a href="index.php">Retornar ao menu</a><br>
		</form>
	</Body>
</html>	